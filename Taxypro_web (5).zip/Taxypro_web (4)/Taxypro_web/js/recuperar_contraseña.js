document.getElementById('recoverForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Aquí puedes agregar lógica para manejar la recuperación de contraseña
    // Por ejemplo, hacer una solicitud POST a tu backend para enviar un correo de recuperación

    const email = document.getElementById('email').value;

    // Mostrar un mensaje de éxito (puedes personalizarlo según lo que quieras hacer)
    alert(`Recuperación de contraseña solicitada para el correo: ${email}`);

    // Resetear el formulario
    document.getElementById('recoverForm').reset();
});
