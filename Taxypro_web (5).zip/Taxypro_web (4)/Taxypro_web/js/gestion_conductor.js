// Función para cargar los conductores desde el almacenamiento local
function loadDrivers() {
    const drivers = JSON.parse(localStorage.getItem('drivers')) || [];
    const driverTableBody = document.getElementById('driverTableBody');
    driverTableBody.innerHTML = ''; // Limpiar la tabla antes de agregar los nuevos datos

    drivers.forEach(driver => {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td>${driver.id}</td>
            <td>${driver.name}</td>
            <td>${driver.surname}</td>
            <td>${driver.phone}</td>
            <td>${driver.email}</td>
            <td><button onclick="deleteDriver(${driver.id})">Eliminar</button></td>
        `;
        driverTableBody.appendChild(newRow);
    });
}

// Función para agregar un conductor
document.getElementById('driverForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtener los datos del formulario
    const driverName = document.getElementById('driverName').value;
    const driverSurname = document.getElementById('driverSurname').value;
    const driverEmail = document.getElementById('driverEmail').value;
    const driverPhone = document.getElementById('driverPhone').value;
    const driverAddress = document.getElementById('driverAddress').value;
    const carType = document.getElementById('carType').value;
    const carPlate = document.getElementById('carPlate').value;

    // Crear un ID único para cada conductor basado en la fecha actual
    const driverId = Date.now();

    // Crear el objeto conductor
    const newDriver = {
        id: driverId,
        name: driverName,
        surname: driverSurname,
        email: driverEmail,
        phone: driverPhone,
        address: driverAddress,
        carType: carType,
        carPlate: carPlate
    };

    // Obtener la lista de conductores desde localStorage o iniciar una lista vacía
    const drivers = JSON.parse(localStorage.getItem('drivers')) || [];
    drivers.push(newDriver);

    // Guardar la nueva lista de conductores en localStorage
    localStorage.setItem('drivers', JSON.stringify(drivers));

    // Limpiar el formulario después de agregar el conductor
    document.getElementById('driverForm').reset();

    // Mostrar los conductores nuevamente
    loadDrivers();

    alert('Conductor agregado exitosamente');
});

// Función para eliminar un conductor
function deleteDriver(driverId) {
    // Obtener la lista de conductores desde localStorage
    const drivers = JSON.parse(localStorage.getItem('drivers')) || [];

    // Filtrar el conductor con el ID que se quiere eliminar
    const updatedDrivers = drivers.filter(driver => driver.id !== driverId);

    // Guardar la nueva lista de conductores en localStorage
    localStorage.setItem('drivers', JSON.stringify(updatedDrivers));

    // Volver a cargar la tabla de conductores
    loadDrivers();
}

// Cargar los conductores cuando la página se carga
window.onload = loadDrivers;
