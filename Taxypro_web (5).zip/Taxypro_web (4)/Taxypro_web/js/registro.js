document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Las contraseñas no coinciden');
        return;
    }

    // Aquí puedes agregar la lógica para guardar los datos de registro, por ejemplo, guardarlos en LocalStorage
    const usuario = {
        firstName,
        lastName,
        email,
        phone,
        password
    };

    // Simulación de guardar en LocalStorage
    localStorage.setItem('usuario', JSON.stringify(usuario));

    // Mensaje de registro exitoso
    alert('Registro exitoso');
    
    // Redirigir al login
    window.location.href = "login.html"; // Redirige a la página de inicio de sesión
});
