document.addEventListener('DOMContentLoaded', () => {
    const botonVerProbabilidad = document.getElementById('verProbabilidad');
    const selectPeriodo = document.getElementById('periodo');

    // Evento al hacer clic en el botón "Ver Probabilidad"
    botonVerProbabilidad.addEventListener('click', () => {
        const periodoSeleccionado = selectPeriodo.value;
        let url;

        // Establecer la URL según el periodo seleccionado
        switch (periodoSeleccionado) {
            case 'mes':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74#scrollTo=a0dMsnG9cHwC'; // URL para "Próximo mes"
                break;
            case 'semestre':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74'; // URL para "Próximo semestre"
                break;
            case 'año':
                url = 'https://colab.research.google.com/drive/17kTZf6aUn2NYUKBOYIErkl918sTJnK74'; // URL para "Próximo año"
                break;
            default:
                alert('Periodo no válido');
                return;
        }

        // Redirigir a la URL correspondiente en una nueva pestaña
        window.open(url, '_blank');
    });

    // Configuración de gráficos
    const probabilidadChartMesCtx = document.getElementById('probabilidadChartMes').getContext('2d');
    const probabilidadChartSemestreCtx = document.getElementById('probabilidadChartSemestre').getContext('2d');
    const probabilidadChartAñoCtx = document.getElementById('probabilidadChartAño').getContext('2d');
    
    let probabilidadChartMes, probabilidadChartSemestre, probabilidadChartAño;

    // Datos simulados basados en el ID de viaje
    const datosSimulados = {
        mes: {
            ids: [101, 102, 103, 104],
            probabilidades: [25, 30, 20, 25]
        },
        semestre: {
            ids: [201, 202, 203, 204],
            probabilidades: [50, 60, 40, 50]
        },
        año: {
            ids: [301, 302, 303, 304],
            probabilidades: [70, 80, 90, 60]
        }
    };

    // Crear gráfico para "Mes"
    probabilidadChartMes = new Chart(probabilidadChartMesCtx, {
        type: 'bar',
        data: {
            labels: datosSimulados.mes.ids,
            datasets: [{
                label: 'Probabilidad de Viaje - Mes',
                data: datosSimulados.mes.probabilidades,
                backgroundColor: 'rgba(255, 99, 132, 0.5)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Crear gráfico para "Semestre"
    probabilidadChartSemestre = new Chart(probabilidadChartSemestreCtx, {
        type: 'line',
        data: {
            labels: datosSimulados.semestre.ids,
            datasets: [{
                label: 'Probabilidad de Viaje - Semestre',
                data: datosSimulados.semestre.probabilidades,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Crear gráfico para "Año"
    probabilidadChartAño = new Chart(probabilidadChartAñoCtx, {
        type: 'pie',
        data: {
            labels: datosSimulados.año.ids,
            datasets: [{
                label: 'Probabilidad de Viaje - Año',
                data: datosSimulados.año.probabilidades,
                backgroundColor: ['rgba(75, 192, 192, 0.5)', 'rgba(153, 102, 255, 0.5)', 'rgba(255, 159, 64, 0.5)', 'rgba(255, 206, 86, 0.5)'],
                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)', 'rgba(255, 206, 86, 1)'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });
});
