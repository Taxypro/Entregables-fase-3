const ctx = document.getElementById('sales-chart').getContext('2d');
let salesChart;

// Datos de ejemplo (puedes integrarlo con tu backend y MySQL)
const ventasDia = [5, 8, 10, 15, 20, 12, 7, 5, 3, 18, 9, 11, 15, 10, 7, 6, 8, 15, 20, 18, 12, 14, 17, 10, 9, 8, 6, 7, 10, 12];
const ventasMes = [300, 400, 320, 500, 450, 480];
const ventasSemestre = [1200, 1500];

// Función para generar gráficos
function generateCharts() {
    if (salesChart) salesChart.destroy(); // Destruye el gráfico anterior para evitar duplicados

    salesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Array.from({ length: ventasDia.length }, (_, i) => `Día ${i + 1}`),
            datasets: [
                {
                    label: 'Viajes del Día',
                    data: ventasDia,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1,
                },
                {
                    label: 'Viajes del Mes',
                    data: ventasMes,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1,
                    barThickness: 20,
                },
                {
                    label: 'Viajes del Semestre',
                    data: ventasSemestre,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1,
                    barThickness: 30,
                },
            ],
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Resumen de Viajes por Día, Mes y Semestre',
                    font: {
                        size: 18,
                    },
                },
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 5,
                    },
                },
                x: {
                    grid: {
                        display: false,
                    },
                },
            },
        },
    });
}

// Función para registrar viajes manualmente
function registrarVenta() {
    const venta = document.getElementById('venta-dia').value;
    const dia = document.getElementById('dia-select').value;

    if (!venta || venta < 0) {
        alert('Por favor ingresa una cantidad válida.');
        return;
    }

    ventasDia[dia - 1] = parseInt(venta);
    alert(`Venta registrada para el Día ${dia}: ${venta}`);
    generateCharts(); // Actualiza el gráfico
}

// Función para eliminar viajes
function eliminarVenta() {
    const dia = document.getElementById('dia-select').value;
    ventasDia[dia - 1] = 0; // Reinicia el valor
    alert(`Venta eliminada para el Día ${dia}`);
    generateCharts();
}

// Genera los gráficos a
