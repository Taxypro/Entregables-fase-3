document.addEventListener('DOMContentLoaded', () => {
    const botonVerProbabilidad = document.getElementById('verProbabilidad');
    const selectPeriodo = document.getElementById('periodo');
    const uploadFileBtn = document.getElementById('uploadFileBtn');
    const csvFileInput = document.getElementById('csvFile');

    const probabilidadChartMesCtx = document.getElementById('probabilidadChartMes').getContext('2d');
    const probabilidadChartSemestreCtx = document.getElementById('probabilidadChartSemestre').getContext('2d');
    const probabilidadChartAñoCtx = document.getElementById('probabilidadChartAño').getContext('2d');
    
    let probabilidadChartMes, probabilidadChartSemestre, probabilidadChartAño;

    // Función para procesar CSV
    const loadCSV = (file) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const contents = event.target.result;
            const data = CSVToArray(contents);
            displayCharts(data);
        };
        reader.readAsText(file);
    };

    // Convertir CSV a array
    const CSVToArray = (strData, strDelimiter = ",") => {
        const lines = strData.trim().split("\n");
        const result = lines.map((line) => line.split(strDelimiter));
        return result;
    };

    // Función para mostrar los gráficos
    const displayCharts = (data) => {
        const labels = data[0].slice(1); // Usar los encabezados (excepto el primero) como etiquetas
        const values = data.slice(1).map(row => row.slice(1).map(Number)); // Extraer los valores

        // Destruir gráficos existentes
        if (probabilidadChartMes) probabilidadChartMes.destroy();
        if (probabilidadChartSemestre) probabilidadChartSemestre.destroy();
        if (probabilidadChartAño) probabilidadChartAño.destroy();

        // Gráfico de Mes
        probabilidadChartMes = new Chart(probabilidadChartMesCtx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Probabilidad de Viaje - Mes',
                    data: values[0],
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });

        // Gráfico de Semestre
        probabilidadChartSemestre = new Chart(probabilidadChartSemestreCtx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Probabilidad de Viaje - Semestre',
                    data: values[1],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });

        // Gráfico de Año
        probabilidadChartAño = new Chart(probabilidadChartAñoCtx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Probabilidad de Viaje - Año',
                    data: values[2],
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true } } }
        });
    };

    // Cargar archivo CSV
    uploadFileBtn.addEventListener('click', () => {
        const file = csvFileInput.files[0];
        if (file) {
            loadCSV(file);
        } else {
            alert("Por favor, selecciona un archivo CSV.");
        }
    });

    // Redirigir a Google Colab
    botonVerProbabilidad.addEventListener('click', () => {
        const periodoSeleccionado = selectPeriodo.value;
        let url;

        switch (periodoSeleccionado) {
            case 'mes':
                url = 'https://colab.research.google.com/drive/ID_DE_MESES';
                break;
            case 'semestre':
                url = 'https://colab.research.google.com/drive/ID_DE_SEMESTRE';
                break;
            case 'año':
                url = 'https://colab.research.google.com/drive/ID_DE_AÑO';
                break;
            default:
                alert('Periodo no válido');
                return;
        }

        window.open(url, '_blank');
    });
});
