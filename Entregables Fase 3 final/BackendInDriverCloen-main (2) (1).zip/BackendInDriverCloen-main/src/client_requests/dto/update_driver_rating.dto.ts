export class UpdateDriverRatingDto {

    id_client_request: number;
    driver_rating: number;

}