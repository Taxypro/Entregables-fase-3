export class UpdateDriverAssignedClientRequestDto {

    id: number;
    id_driver_assigned: number;
    fare_assigned: number;

}