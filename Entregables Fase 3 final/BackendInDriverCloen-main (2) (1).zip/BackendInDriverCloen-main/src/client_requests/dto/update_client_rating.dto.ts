export class UpdateClientRatingDto {

    id_client_request: number;
    client_rating: number;

}