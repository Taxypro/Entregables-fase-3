export class CreateDriverTripOffersDto {

    id_driver: number;
    fare_offered: number;
    time: number;
    distance: number;
    id_client_request: number;
    

}