export class CreateDriverPositionDto {

    id_driver: number;
    lat: number;
    lng: number;

}