export class CreateDriverCarInfoDto {

    id_driver: number;
    brand: string;
    plate: string;
    color: string;

}