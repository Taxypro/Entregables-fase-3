export enum JwtRole {
    CLIENT = 'CLIENT',
    ADMIN = 'ADMIN',
}