export const jwtConstants = {
    secret: 'mi_clave_de_seguridad'
}